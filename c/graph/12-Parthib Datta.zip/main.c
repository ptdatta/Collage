#include <stdio.h>
#include <stdlib.h>

typedef struct N
{
    int data;
    struct N *next;
} Node;

Node *insert(Node *head, int val)
{
    Node *temp;
    temp = (Node *)malloc(sizeof(Node));
    temp->data = val;
    temp->next = NULL;
    if (head == NULL)
    {
        return temp;
    }
    Node *p = head;
    while (p->next != NULL)
    {
        p = p->next;
    }
    p->next = temp;
    return head;
}

void display(Node *head)
{
    Node *temp = head;
    while (temp != NULL)
    {
        printf("%d->", temp->data);
        temp = temp->next;
    }
    printf("\n");
}

int main()
{
    FILE *fpr;
    fpr = fopen("E:\\collage\\c\\graph\\graph.txt", "r");
    if (fpr == NULL)
    {
        printf("Not opened");
    }
    char c;
    int n;
    fscanf(fpr, "%c%d", &c, &n);
    int **arr;
    arr = (int **)malloc(n * sizeof(int *));
    for (int i = 0; i < n; i++)
    {
        arr[i] = (int *)malloc(n * sizeof(int));
        for (int j = 0; j < n; j++)
        {
            fscanf(fpr, "%d", &arr[i][j]);
        }
    }
    int count = 0, x = 0;
    for (int i = 0; i < n; i++)
    {
        int c = 0;
        Node *head = NULL;
        head = insert(head, i + 1);
        for (int j = 0; j < n; j++)
        {
            if (arr[i][j] == 1)
            {
                c++;
                head = insert(head, j + 1);
            }
            if (arr[i][j] == 1 && arr[j][i] != 1)
            {
                count++;
            }
            else if (arr[i][j] == 1 && arr[j][i] && i != j)
            {
                x++;
            }
        }
        display(head);
        printf("In-degree vertices are %d and Out-degree vertices are %d for %d\n", 4 - c, c, i + 1);
    }
    printf("Total number of edges %d\n", count + (x / 2));
    return 0;
}
